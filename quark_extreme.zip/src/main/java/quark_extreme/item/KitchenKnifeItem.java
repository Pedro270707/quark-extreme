
package quark_extreme.item;

import quark_extreme.itemgroup.QuarkExtremeItemGroup;

import quark_extreme.QuarkExtremeModElements;

import net.minecraftforge.registries.ObjectHolder;

import net.minecraft.item.crafting.Ingredient;
import net.minecraft.item.SwordItem;
import net.minecraft.item.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Item;
import net.minecraft.item.IItemTier;

@QuarkExtremeModElements.ModElement.Tag
public class KitchenKnifeItem extends QuarkExtremeModElements.ModElement {
	@ObjectHolder("quark_extreme:kitchen_knife")
	public static final Item block = null;
	public KitchenKnifeItem(QuarkExtremeModElements instance) {
		super(instance, 56);
	}

	@Override
	public void initElements() {
		elements.items.add(() -> new SwordItem(new IItemTier() {
			public int getMaxUses() {
				return 651;
			}

			public float getEfficiency() {
				return 5f;
			}

			public float getAttackDamage() {
				return 2f;
			}

			public int getHarvestLevel() {
				return 1;
			}

			public int getEnchantability() {
				return 15;
			}

			public Ingredient getRepairMaterial() {
				return Ingredient.fromStacks(new ItemStack(Items.IRON_INGOT));
			}
		}, 3, 0f, new Item.Properties().group(QuarkExtremeItemGroup.tab)) {
		}.setRegistryName("kitchen_knife"));
	}
}
