
package quark_extreme.item;

import quark_extreme.itemgroup.QuarkExtremeItemGroup;

import quark_extreme.QuarkExtremeModElements;

import net.minecraftforge.registries.ObjectHolder;

import net.minecraft.item.Rarity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Item;
import net.minecraft.block.BlockState;

@QuarkExtremeModElements.ModElement.Tag
public class EndSugiliteItem extends QuarkExtremeModElements.ModElement {
	@ObjectHolder("quark_extreme:end_sugilite")
	public static final Item block = null;
	public EndSugiliteItem(QuarkExtremeModElements instance) {
		super(instance, 59);
	}

	@Override
	public void initElements() {
		elements.items.add(() -> new ItemCustom());
	}
	public static class ItemCustom extends Item {
		public ItemCustom() {
			super(new Item.Properties().group(QuarkExtremeItemGroup.tab).maxStackSize(64).rarity(Rarity.COMMON));
			setRegistryName("end_sugilite");
		}

		@Override
		public int getItemEnchantability() {
			return 0;
		}

		@Override
		public int getUseDuration(ItemStack itemstack) {
			return 0;
		}

		@Override
		public float getDestroySpeed(ItemStack par1ItemStack, BlockState par2Block) {
			return 1F;
		}
	}
}
