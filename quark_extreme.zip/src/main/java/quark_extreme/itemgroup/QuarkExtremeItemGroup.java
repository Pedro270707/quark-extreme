
package quark_extreme.itemgroup;

import quark_extreme.block.EndCrustoseBlock;

import quark_extreme.QuarkExtremeModElements;

import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemGroup;

@QuarkExtremeModElements.ModElement.Tag
public class QuarkExtremeItemGroup extends QuarkExtremeModElements.ModElement {
	public QuarkExtremeItemGroup(QuarkExtremeModElements instance) {
		super(instance, 15);
	}

	@Override
	public void initElements() {
		tab = new ItemGroup("tabquark_extreme") {
			@OnlyIn(Dist.CLIENT)
			@Override
			public ItemStack createIcon() {
				return new ItemStack(EndCrustoseBlock.block);
			}

			@OnlyIn(Dist.CLIENT)
			public boolean hasSearchBar() {
				return false;
			}
		};
	}
	public static ItemGroup tab;
}
