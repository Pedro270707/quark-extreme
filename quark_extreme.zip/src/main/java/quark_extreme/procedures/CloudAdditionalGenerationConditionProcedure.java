package quark_extreme.procedures;

import quark_extreme.QuarkExtremeMod;

import java.util.Map;

public class CloudAdditionalGenerationConditionProcedure {
	public static boolean executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("y") == null) {
			if (!dependencies.containsKey("y"))
				QuarkExtremeMod.LOGGER.warn("Failed to load dependency y for procedure CloudAdditionalGenerationCondition!");
			return false;
		}
		double y = dependencies.get("y") instanceof Integer ? (int) dependencies.get("y") : (double) dependencies.get("y");
		return (y > 125);
	}
}
